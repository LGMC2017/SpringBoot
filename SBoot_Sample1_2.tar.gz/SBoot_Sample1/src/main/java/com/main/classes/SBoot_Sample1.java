package com.main.classes;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.swing.JOptionPane;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class SBoot_Sample1 {

	public static void main(String[] args) {
		JOptionPane.showMessageDialog(null, "SpringBoot Working");
		ConfigurableApplicationContext ctx = SpringApplication.run(SBoot_Sample1.class, args);
		
		ExecutorService execsrv = Executors.newSingleThreadExecutor();
		
		execsrv.execute(() -> {
			System.out.println("Service Running");
		});
		
		execsrv.shutdown();
		
		ctx.getBean(SBoot_Sample1.class);
		ctx.close();
	}

}
